

<div class='dashboard'>
<div class='dashboard-app'>
        <header class='dashboard-toolbar'><a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a>     <h1>Bem vindo(a) ao O Estokke <?php echo $_SESSION['user']; ?></h1>    <span>&emsp;</span> <p>Você esta logado como Adiministrador</p> </header>
        <div class='dashboard-content'>
            <div class='container'>
                <div class='card'>

                    <div class='card-header'>
                        <h1>Grafico de Vendas</h1>
                    </div>
                </div>
            <div class="container-fluid">        
                            <div class="row cards-intro">
                                <div class="col-sm-3">
                                    <div class="card-graf">
                                        <div class="card-body">
                                            <h5 class="card-title">
                                            <?php echo totalAlunos(); ?>
                                            </h5>
                                            
                                            <p class="card-text">Total de Produtos</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-graf">
                                        <div class="card-body">
                                            <h5 class="card-title">
                                            <?php
                                            echo totalVendas();
                                            ?>
                                            </h5>
                                            <p class="card-text">Valor Total</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-graf">
                                        <div class="card-body">
                                            <h5 class="card-title">
                                        <?php
                                        echo quantidade();
                                        ?>
                                        </h5>
                                            <p class="card-text">Quantidade de Produtos</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="card-graf">
                                        <div class="card-body">
                                            <h5 class="card-title">0</h5>
                                            <p class="card-text">Total de Alunos</p>
                                        </div>
                                    </div>
                                </div>
                            </div>        
                        </div>
                        
                        <div class="col-lg-12">
                            <div class="grafico">
                                <div id="chartdiv">
                                    <?php include "graf.php"; ?>
                                </div>
                            </div>
                        </div>


                        </div>
                        </div>
                        </div>
</div>
</div>
