<body>
<div class='dashboard'>
<div class='dashboard-app'>
        <header class='dashboard-toolbar'><a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a>     <h5>Bem vindo(a) Estokke <?php echo $_SESSION['user']; ?></h5>    <span>&emsp;</span> <h6>Você esta logado como Adiministrador</h6> </header>
        <div class='dashboard-content'>
            <div class='container'>
            <div class='card'>
                    <div class='card-header'>
                    <h4>CADASTRO DE PRODUTOS</h4>
                    </div>
                </div>
                    <div class="container-fluid form-aluno">                  
                      <form  class="row g-3" method="post" action="painel.php?r=cadAluno" runat="server" id="form" onsubmit="onLoginFormSubmit(event)" >
                                  <div class="col-md-6">
                                    <label  class="form-label">Nome do Produto</label>
                                    <input type="text" class="form-control" name="nome_produto" required>
                                  </div>
                                  <div class="col-md-6">
                                    <label class="form-label">Data</label>
                                    <input type="text" class="form-control" name="data_cadastro" value="<?php echo date("d/m/Y"); ?>" readonly >
                                  </div>
                                  <div class="col-6">
                                    <label class="form-label">Valor de Custo</label>
                                    <input type="text" class="form-control" name="custo_produto" required>
                                  </div>
                                  <div class="col-6">
                                    <label for="inputAddress2" class="form-label">Valor de Venda</label >
                                    <input type="text" class="form-control" name="valor_venda" required>
                                  </div>
                                  <div class="col-md-6">
                                    <label class="form-label">Codigo do Produto</label>
                                    <input type="text" class="form-control" name="id"  required >
                                  </div>
                                  <div class="col-6">
                                    <label for="inputAddress2" class="form-label">Fornecedor</label >
                                    <input type="text" class="form-control" name="fornecedor" required>
                                  </div>
                                  <div class="col-12">
                                    <label for="inputAddress2" class="form-label">Quantidade</label >
                                    <input type="text" class="form-control" name="quantidade" required>
                                  </div>
                                  <div class="col-12">
                                    <button type="submit"  class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"  >Salvar</button>
                                  </div>
                            </form>
                          </div>
                      <?php
                        if(isset($_POST['nome_produto']))
                        {
                        if(cadastrar($_POST)){
                            ?>
                            <script type="text/javascript">
                            Swal.fire({
                              icon: 'success',
                              title: 'Produto Cadastrado',
                              showConfirmButton: false,
                              timer: 1500
                            })
                            </script>
                            <?php
                            
                          }else{
                            ?>
                            <script type="text/javascript">
                            Swal.fire({
                              icon: 'error',
                              title: 'Produto não cadastrado',
                              showConfirmButton: false,
                              timer: 1500
                            })
                            </script>
                            <?php
                          };
                      }
                      ?>
                </div>
  </div>
  <!-- <script src="_js/login.js"></script> -->
<script>
  //   function data(){
  //   date = new Date().toLocaleDateString();
  //   document.write(date);
  // }
</script>
</div>
</body>