<body>
<div class='dashboard'>
<div class='dashboard-app'>
        <header class='dashboard-toolbar'><a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a>     <h1>Bem vindo(a) ao O Estokke <?php echo $_SESSION['user']; ?></h1>    <span>&emsp;</span> <p>Você esta logado como Adiministrador</p> </header>
        <div class='dashboard-content'>
            <div class='container'>
            <div class='card'>
                    <div class='card-header'>
                    <h1>CADASTRO DE USUARIOS</h1>
                    </div>
                </div>
                    <div class="container-fluid form-aluno">                  
                      <form  class="row g-3" method="post" action="painel.php?r=cadUser" runat="server" id="form" onsubmit="onLoginFormSubmit(event)" >
                                  <div class="col-md-6">
                                    <label  class="form-label">Nome do Usuario</label>
                                    <input type="text" class="form-control" name="nome_user" required>
                                  </div>
                                  <div class="col-md-6">
                                    <label class="form-label">Data</label>
                                    <input type="text" class="form-control" name="data_cadUser" value="<?php echo date("d/m/Y"); ?>" readonly >
                                  </div>
                                  <div class="col-md-6">
                                    <label class="form-label">Codigo do Usuario</label>
                                    <input type="text" class="form-control" name="id"  required >
                                  </div>
                                  <div class="col-md-6">
                                    <label class="form-label">Senha</label>
                                    <input type="text" class="form-control" name="senha"  required >
                                  </div>
                                  <div class="col-md-12">
                                      <label class="form-label">Tipo</label>
                                      <select class="form-select" name="tipo"  >
                                        <option value="VENDEDOR">VENDEDOR</option>
                                        <option value="ADM">ADMINISTRADOR</option>
                                      </select>
                                    </div>
                                  <div class="col-12">
                                    <button type="submit"  class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"  >Salvar</button>
                                  </div>
                            </form>
                          </div>
                      <?php
                        if(isset($_POST['nome_user']))
                        {
                          if(cadastrarUser($_POST)){
                            ?>
                            <script type="text/javascript">
                            Swal.fire({
                              icon: 'success',
                              title: 'Usuario Cadastrado',
                              showConfirmButton: false,
                              timer: 1500
                            })
                            </script>
                            <?php
                          }else{
                            ?>
                            <script type="text/javascript">
                            Swal.fire({
                              icon: 'error',
                              title: 'Usuario não cadastrado',
                              showConfirmButton: false,
                              timer: 1500
                            })
                            </script>
                            <?php
                          };
                      }
                      ?>
                </div>
  </div>
  <!-- <script>
    function data(){
    date = new Date().toLocaleDateString();
    document.write(date);
  }
</script> -->
</div>
</body>