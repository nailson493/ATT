// function onLoginFormSubmit(event) {
    
//     var loading = document.getElementById('load')
//     loading.style.display = 'block'
// }  
document.querySelector(".first").addEventListener('click', function(){
    Swal.fire({
  icon: 'success',
  title: 'Your work has been saved',
  showConfirmButton: false,
  timer: 1500
})
  });
  
  document.querySelector(".second").addEventListener('click', function(){
    Swal.fire("Our First Alert", "With some body text!");
  });
  
  document.querySelector(".third").addEventListener('click', function(){
    Swal.fire("Our First Alert", "With some body text and success icon!", "success");
  });