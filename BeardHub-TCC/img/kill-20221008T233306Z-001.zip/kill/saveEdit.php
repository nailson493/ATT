<?php


include "_scripts/config.php";

        if(isset($_POST['update'])){ 


            $nome = $_POST['nome_produto'];
            $data = $_POST['data_cadastro'];
            $valor_custo = $_POST['custo_produto'];
            $valor_venda = $_POST['valor_venda'];
            $id = $_POST['id'];
            $fornecedor = $_POST['fornecedor'];

            $sqlUpdate = "UPDATE cad_produto SET nome_produto='$nome', data_cadastro='$data', custo_produto='$valor_custo', valor_venda='$valor_venda', fornecedor='$fornecedor'    
            WHERE id='$id' ";

            $result = $mysqli->query($sqlUpdate);
     }
     header('Location: painel.php?r=mostrarAluno ')

?> 