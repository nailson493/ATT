<?php

    function cadastrar($dados){

        include "_scripts/config.php";

        $nome = $dados['nome_produto'];
        $data = $dados['data_cadastro'];
        $valor_custo = $dados['custo_produto'];
        $valor_venda = $dados['valor_venda'];
        $id = $dados['id'];
        $fornecedor = $dados['fornecedor'];
        $quantidade = $dados['quantidade'];


        $sql = "INSERT INTO cad_produto (nome_produto,data_cadastro,custo_produto,valor_venda,id,fornecedor,quantidade) VALUES ('$nome','$data','$valor_custo','$valor_venda','$id','$fornecedor',$quantidade)";
        $query = $mysqli->query($sql);
        return $query;
        
        
    }
    


    function totalVendas(){//QUANTIDADE DE PROFESSORES NA BASE

        include "_scripts/config.php";
          
        $sql = "SELECT SUM(custo_produto) AS 'total' FROM cad_produto";
        $resultado = mysqli_query($mysqli, $sql);
        $total = mysqli_fetch_array($resultado);
        echo $total['total'];
    
    }


    function quantidade(){//QUANTIDADE DE PROFESSORES NA BASE

        include "_scripts/config.php";
          
        $sql = "SELECT SUM(quantidade) AS 'total' FROM cad_produto";
        $resultado = mysqli_query($mysqli, $sql);
        $total = mysqli_fetch_array($resultado);
        echo $total['total'];
    
    }





    function cadastrarUser($dados){

        include "_scripts/config.php";

        $nome = $dados['nome_user'];
        $data = $dados['data_cadUser'];
        $id = $dados['id'];
        $tipo = $dados['tipo'];
        $senha = $dados['senha'];

        $sql = "INSERT INTO dados_user (nome,data_cadUser,id,tipo,senha) VALUES ('$nome','$data','$id','$tipo','$senha')";
        $query = $mysqli->query($sql);
        return $query;

    }
   



    function validaUser($DADOS){

        include "_scripts/config.php";
        if(!empty($DADOS['senha'])){
    
        $user = $DADOS['usuario'];
        $senha = $DADOS['senha'];
    
        $sql = "SELECT nome, senha FROM dados_user WHERE nome = '$user' AND senha = '$senha'";
        $query = $mysqli->query($sql);
    
        if(mysqli_num_rows($query) > 0){
            return true;
        } else{
            return false;
        }
    
        }
    }   

    

    
   
    
    function totalAlunos(){//QUANTIDADE DE ALUNOS NA BASE
    
        include "_scripts/config.php";
          
        $sql = "SELECT id FROM  cad_produto";
        $query = $mysqli->query($sql);
        $total = $query->num_rows;
    
        return $total;  
    
    }
    

    




function verificar($dados){
        ob_start();

        include "_scripts/config.php";
                
        $id = $_GET['id'];

        if(!empty($_GET['id'])){

        $sqlSelect = "SELECT * FROM cad_produto WHERE id=$id";

        $result = $mysqli->query($sqlSelect);
        print_r($result);

        if($result->num_rows > 0 )
        { 
            while($user_data = mysqli_fetch_assoc($result)){ 

            $nome = $user_data['nome_produto'];
            $data = $user_data['data_cadastro'];
            $valor_custo = $user_data['custo_produto'];
            $valor_venda = $user_data['valor_venda'];
            $id = $user_data['id'];
            $fornecedor = $user_data['fornecedor'];
        }
        print_r($nome);
        }
        else
        { 
            header("Location: menu.php");
            ob_end_flush();
        }
        }
}

















?>

