<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
<script type="text/javascript" src=".../js/refresh.js"></script>
    

    <script src="tailwind.js"></script>
    <script src="_js/login.js"></script>
    <script src="/fontawesome/js/all.js" ></script>
    <script src="_js/login.js"></script>
    <script src="_js/login.js"></script>
    <script src="_js/login.js"></script>