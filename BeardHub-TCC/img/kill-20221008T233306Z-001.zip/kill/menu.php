<body>
<div class='dashboard'>
    <div class="dashboard-nav">
        <header>
            <a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a>
            <a href="#"  class="brand-logo"><i class="fa-solid fa-blanket"></i>
            <i class="fa-solid fa-box"></i> <span>ESTOQUE</span></a>
            <?php
                session_start();
            ?>
        </header>
        <nav class="dashboard-nav-list"><a href="painel.php?r=home" class="dashboard-nav-item"><i class="fas fa-home"></i>Home </a>
            <a href="painel.php?r=home" class="dashboard-nav-item active"><i class="fas fa-tachometer-alt"></i> Monitoramento</a>
            <a href="#" class="dashboard-nav-item"><i class="fas fa-file-upload"></i> Upload </a>
            <div class='dashboard-nav-dropdown'><a href="#!" class="dashboard-nav-item dashboard-nav-dropdown-toggle">
            <i class="fa-solid fa-list"></i> Produtos </a>
                <div class='dashboard-nav-dropdown-menu'>
                    <a href="painel.php?r=cadAluno" class="dashboard-nav-dropdown-item">Cadastrar Produtos</a>
                    <a href="painel.php?r=mostrarAluno" class="dashboard-nav-dropdown-item">Mostrar Produtos</a>
                    <a href="#" class="dashboard-nav-dropdown-item">Images</a>
                    <a href="#" class="dashboard-nav-dropdown-item">Video</a>
                </div>
            </div>
            <div class='dashboard-nav-dropdown'>
                <a href="#!" class="dashboard-nav-item dashboard-nav-dropdown-toggle"><i class="fas fa-users"></i> Controle</a>
                <div class='dashboard-nav-dropdown-menu'>
                    <a href="#" class="dashboard-nav-dropdown-item">All</a>
                    <a href="painel.php?r=cadUser" class="dashboard-nav-dropdown-item">Cadastrar usuario</a>
                    <a href="#" class="dashboard-nav-dropdown-item">Non-subscribed</a>
                    <a href="#" class="dashboard-nav-dropdown-item">Banned</a>
                    <a href="#" class="dashboard-nav-dropdown-item">New</a>
                </div>
            </div>
            <div class='dashboard-nav-dropdown'><a href="#!" class="dashboard-nav-item dashboard-nav-dropdown-toggle"><i
                    class="fas fa-money-check-alt"></i> Payments </a>
                <div class='dashboard-nav-dropdown-menu'><a href="#"
                                                            class="dashboard-nav-dropdown-item">All</a><a
                        href="#" class="dashboard-nav-dropdown-item">Recent</a><a
                        href="#" class="dashboard-nav-dropdown-item"> Projections</a>
                </div>
            </div>
            <a href="#" class="dashboard-nav-item"><i class="fas fa-cogs"></i> Settings </a><a
                    href="#" class="dashboard-nav-item"><i class="fas fa-user"></i> Profile </a>
          <div class="nav-item-divider"></div>
          <a
                    href="logout.php" class="dashboard-nav-item"><i class="fas fa-sign-out-alt"></i> Logout </a>
        </nav>
    </div>
    <!-- <div class='dashboard-app'>
        <header class='dashboard-toolbar'><a href="#!" class="menu-toggle"><i class="fas fa-bars"></i></a></header>
        <div class='dashboard-content'>
            <div class='container'>
                <div class='card'>
                    <div class='card-header'>
                        <h1>Welcome back Jim</h1>
                    </div>
                    <div class='card-body'>
                        <p>Your account type is: Administrator</p>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
<!-- </div> -->

</body>
<!-- partial -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js'></script><script  src="./script.js"></script>
<script  src="./script.js"></script>