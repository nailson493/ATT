<?php
 include "header.php";
?>
<body>
    <?php
    include "menu.php";
 
    switch($_GET['r']){

        case 'cadAluno':
            include "views/cadAluno.php";
            break;
        case 'mostrarAluno':
            include "views/mostrarAluno.php";
            break;
        case 'editProduto':
            include "views/editProduto.php";
            break;
        case 'cadUser':
            include "views/cadUser.php";
            break;
        default:
            include "views/home.php";
            break;
        

    }
    
    
    ?>
    <?php include "js.php"; ?>
</body>
</html>