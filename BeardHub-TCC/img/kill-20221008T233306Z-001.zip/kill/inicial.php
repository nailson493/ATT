<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="_images/logo.png">
    <title>O ESTOKKE : LOGIN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="_css/login.css" type="text/css" rel="stylesheet">
    <link href="_css/pag.css" type="text/css" rel="stylesheet">
  </head>
  
  <div class="loader" id ="load">
    <div class="inner one"></div>
    <div class="inner two"></div>
    <div class="inner three"></div>
  </div>
 

  
  <body class="text-center gradient">
    <form  name="qrcodeRedirectForm" class="form-signin" action="login.php" method="post" onsubmit="onLoginFormSubmit(event)"  >
        <img class="mb-4" src="_images/logo.png" alt="Tela de Login" width="100px" height="100px">
        <h1 class="h3 mb-3 font-weight-normal">O ESTOKKE</h1>
       
        <input type="text" id="inputEmail" class="form-control" placeholder="Usuario" name="usuario" required autofocus>
        <input type="password" id="inputPassword" class="form-control mt-3" placeholder="Senha" name="senha" required><br>
        <button  onclick="delayedMessage();" class="hvr-shutter-in-horizontal"   id="btn-div" type="submit">Login</button>
        <p class="mt-5 mb-3 text-muted">&copy; 2022</p>
    </form>
    <script type="text/javascript">
	
  function delayedMessage(){
			setTimeout('document.qrcodeRedirectForm.submit()', 2000)
		}

   
  function onLoginFormSubmit(event) {
  event.preventDefault();
  //debugger;

  var loading = document.getElementById('load')
  loading.style.display = 'block'
 }

var btn = document.getElementById('btn-div');
var container = document.querySelector('.form-signin');
btn.addEventListener('click', function() {
container.style.display = 'none';

});










	</script>
  </body>
</html>



