<?php
require "_scripts/config.php";
require "_scripts/functions.php";

if(validaUser($_POST)){
    session_start();
    $_SESSION["user"]= $_POST["usuario"];
    $_SESSION["senha"]= $_POST["senha"];
    header("Location: painel.php?r=0");
}else{
    header("Location: inicial.php");
    
}


