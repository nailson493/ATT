function onLoginFormSubmit(event) {
    
    var loading = document.getElementById('load')
    loading.style.display = 'block'



}  


setTimeout(function() {
  console.log("TEstanto")
}, 1000);



document.querySelector(".first").addEventListener('click', function(){
  Swal.fire("Our First Alert");
});

document.querySelector(".second").addEventListener('click', function(){
  Swal.fire("Our First Alert", "With some body text!");
});

document.querySelector(".third").addEventListener('click', function(){
  Swal.fire("Our First Alert", "With some body text and success icon!", "success");
});