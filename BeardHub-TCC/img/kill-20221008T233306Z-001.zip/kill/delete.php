<?php
    if(!empty($_GET['id']))
    {
        include "_scripts/config.php";

        $id = $_GET['id'];

        $sqlSelect = "SELECT *  FROM cad_produto WHERE id=$id";

        $result = $mysqli->query($sqlSelect);

        if($result->num_rows > 0)
        {
            $sqlDelete = "DELETE FROM cad_produto WHERE id=$id";
            $resultDelete = $mysqli->query($sqlDelete);
        }
    }
    header('Location: painel.php?r=mostrarAluno');
   
?>